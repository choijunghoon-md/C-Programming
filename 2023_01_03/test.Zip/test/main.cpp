#define MAX_LEN 100
#include <stdio.h>

int main()
{
	FILE* fs;
	fs = fopen("data1.txt", "r");
	while (feof(fs) == 0) {
		char str[MAX_LEN];
		fgets(str, MAX_LEN, fs);
		printf("%s", str);
	}
	fclose(fs);
}


void ex1(void){
	FILE* fs;
	fs = fopen("data1.txt", "r");
	char str[MAX_LEN];
	fgets(str, MAX_LEN, fs);
	printf("%s", str);  //�ѱ���� �ν��� ���� ����
}